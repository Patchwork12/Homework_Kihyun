#include <iostream>
#include <Windows.h>
#include <conio.h>
#include "int4.h"
#include "ConsoleScreen.h"
#include "Player.h"
#include "Wall.h"
#include "Unit.h"
#include "GameManager.h"
#include "Bullet.h"

class Wall;
class Player;




void GameManager::SetGame()
{

    Screen.Init('-');


    MainPlayer.SetPos({ 10, 5 });


    int Count = 0;




    while (true)
    {
        //�÷��̾� ����
        Screen.Clear();
        Screen.SetPixel(MainPlayer.GetPos(), 'a');


        //�� ����
        for (int i = 0; i < 5; i++)
        {
            if (&Walls[i] == nullptr)
            {
                continue;
            }

            // int4 WallPos = PtrWall.GetPos();
            // int4 WallPos = ArrWall[i].GetPos();
            int4 WallPos = {5 + Count, i};
            Walls[i].SetPos(WallPos);
            Screen.SetPixel(Walls[i].GetPos(), '#');
        }

        //�Ѿ� ����


        for (int i = 0; i < 10; i++)
        {
            if (true == Bullets[i].OnBullet)
            {
                Screen.SetPixel(Bullets[i].GetPos(), '*');
                Bullets[i].MoveBullet();
                HitBullet();
  
            }

        }


        // ++Count;

        Screen.Print();

        //ȭ�� �ʱ�ȭ
        if (0 != _kbhit())
        {
            GameManager::Input();

        }
        // 1�� ���� �����մϴ�.
        Sleep(100); 

        int a = 0;
    }

    //while (true)
    //{
    //    Screen.Clear();
    //    Screen.SetPixel(MainPlayer.GetPos(), 'a');
    //    Screen.Print();

    //    MainPlayer.Input(&Screen);
    //}
}




void GameManager::BulletShoot()
{
    int4 SetBullet = { 0, 0 };
    SetBullet = MainPlayer.GetPos();

    for (int i = 0; i < 10; i++)
    {
        if (false == Bullets[i].OnBullet)
        {
            Bullets[i].SetPos(SetBullet);
            Screen.SetPixel(Bullets[i].GetPos(), '*');
            Bullets[i].OnBullet = true;
            break;
        }

    }

    int a = 0;
}

void GameManager::HitBullet()
{


    for (int i = 0; i < 10; i++)
    {

        int4 TemBulletPos = Bullets[i].GetPos() + Up;

        if (TemBulletPos == Walls[i].GetPos())
        {

             Bullets[i].OnBullet = false;

             break;
        }
    }

}



void GameManager::Input()
{
    char Select = (char)_getch();


    int4 MovePos = { 0, 0 };


    switch (Select)
    {
    case 'a':
    {
        MovePos = Left;


        break;
    }
    case 'd':
    {
        MovePos = Right;

        break;
    }
    case 'w':
    {

        MovePos = Up;

        break;
    }

    case 's':
    {
        MovePos = Down;
        break;
    }

    case ' ':
    {
        BulletShoot();
        break;
    
    }
    default:
        break;
    }

    int4 TempPlayerPos = MainPlayer.GetPos() + MovePos;

    for (int i = 0; i < 10; i++)
    {


        if (TempPlayerPos == Walls[i].GetPos())
        {
            MovePos = Stop;
            break;
        }

        int a = 0;

    }


    if (false == Screen.IsScreenOut(MainPlayer.GetPos() + MovePos))
    {


        MainPlayer.AddPos(MovePos);

        int a = 0;
    }

    int a = 0;
}
