#pragma once
#include <iostream>
#include <conio.h>
#include "Unit.h"


class Wall : public Unit
{
public:

    Wall();

    //bool IsWall(const int4& _Pos);


protected:

private:


};
