#include "Wall.h"
#include "int4.h"
#include "ConsoleScreen.h"

class int4;


Wall::Wall()
{

}

